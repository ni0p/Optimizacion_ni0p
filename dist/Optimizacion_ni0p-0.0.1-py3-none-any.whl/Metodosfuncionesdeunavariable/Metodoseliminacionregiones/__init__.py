#Metodos de eliminación de regiones
from bounding_phase_method import bounding_p_m
from fibonacci import fibonacci_search
from golden_search_method import golden_search