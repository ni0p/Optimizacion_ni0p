from busqueda_exhaustiva import *
from interval_halving_method import *