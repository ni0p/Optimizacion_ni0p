#Introduccion
from latax2 import volumen_lata
from caja import volumen_caja
from cerca import ecuacion_cerca