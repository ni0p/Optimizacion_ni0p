#Metodos basados en la derivada
from .newton_rhapson import linspace, derivada, segunda_derivada, delta_x, caja, lata, f1, f2, f3, f4, newton_method
from .biseccion import linspace, derivada, segunda_derivada, delta_x, caja, lata, f1, f2, f3, f4, biseccion
from .secante import linspace, derivada, segunda_derivada, delta_x, caja, lata, f1, f2, f3, f4, secante 