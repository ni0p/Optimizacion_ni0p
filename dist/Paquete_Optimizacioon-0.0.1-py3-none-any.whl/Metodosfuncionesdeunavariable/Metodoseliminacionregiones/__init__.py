#Metodos de eliminación de regiones
from .bounding_phase_method import linspace, caja, lata, f1, f2, f3, f4, bounding_p_m
from .fibonacci import linspace, caja, lata, f1, f2, f3, f4, fibonacci_search
from .golden_search_method import linspace, caja, lata, f1, f2, f3, f4, golden_search