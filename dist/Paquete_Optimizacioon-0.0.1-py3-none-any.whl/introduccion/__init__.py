#Introduccion
from .latax2 import linspace, volumen_lata
from .caja import linspace, volumen_caja
from .cerca import linspace, ecuacion_cerca 