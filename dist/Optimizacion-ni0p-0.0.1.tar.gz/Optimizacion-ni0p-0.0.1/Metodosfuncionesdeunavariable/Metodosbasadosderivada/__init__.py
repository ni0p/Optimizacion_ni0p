#Metodos basados en la derivada
from newton_rhapson import newton_method
from biseccion import biseccion
from secante import secante